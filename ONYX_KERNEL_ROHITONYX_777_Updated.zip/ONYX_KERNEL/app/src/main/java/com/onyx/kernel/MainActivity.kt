package com.onyx.kernel

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipFile

private val Ink = Color(0xFF090A0D)
private val Panel = Color(0xFF17191F)
private val Panel2 = Color(0xFF20232B)
private val Red = Color(0xFF20C8FF) // Electric blue accent; no silver or red branding
private val Gold = Color(0xFFFFC247)
private val Purple = Color(0xFFB45CFF)
private val Muted = Color(0xFF9CA3AF)
private val White = Color(0xFFF5F5F7)

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OnyxApp(this) }
    }
}

data class ModuleItem(val name: String, val version: String, val description: String, val fileName: String)

@Composable
fun OnyxApp(context: Context) {
    val activity = context as FragmentActivity
    val securityPrefs = remember { context.getSharedPreferences("onyx_security", Context.MODE_PRIVATE) }
    var pinHash by remember { mutableStateOf(securityPrefs.getString("pin_hash", null)) }
    var pinSalt by remember { mutableStateOf(securityPrefs.getString("pin_salt", null)) }
    var fingerprintEnabled by remember { mutableStateOf(securityPrefs.getBoolean("fingerprint_enabled", false)) }
    var unlocked by remember { mutableStateOf(false) }
    var pinInput by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf("") }
    var isSettingPin by remember { mutableStateOf(pinHash == null) }
    val biometricAvailable = remember {
        BiometricManager.from(context).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS
    }
    fun savePin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val saltText = Base64.encodeToString(salt, Base64.NO_WRAP)
        val hashText = hashPin(pin, salt)
        securityPrefs.edit().putString("pin_salt", saltText).putString("pin_hash", hashText).apply()
        pinSalt = saltText; pinHash = hashText; pinInput = ""; confirmPin = ""; pinError = ""
        isSettingPin = false; unlocked = true
    }
    fun verifyPin(pin: String): Boolean {
        val saltText = pinSalt ?: return false
        val expected = pinHash ?: return false
        val salt = Base64.decode(saltText, Base64.NO_WRAP)
        return MessageDigest.isEqual(hashPin(pin, salt).toByteArray(), expected.toByteArray())
    }
    fun launchBiometric() {
        val executor = ContextCompat.getMainExecutor(context)
        val prompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                unlocked = true; pinError = ""; pinInput = ""
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                pinError = errString.toString()
            }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock ONYX KERNEL")
            .setSubtitle("Use your fingerprint or enter your PIN")
            .setNegativeButtonText("Use PIN")
            .build()
        prompt.authenticate(info)
    }
    val root = remember { File(context.filesDir, "onyx").apply { mkdirs() } }
    val archives = remember { File(root, "archives").apply { mkdirs() } }
    val modulesDir = remember { File(root, "modules").apply { mkdirs() } }
    var page by remember { mutableStateOf("Home") }
    var refresh by remember { mutableIntStateOf(0) }
    var selectedZip by remember { mutableStateOf<File?>(null) }
    var message by remember { mutableStateOf("") }
    var showAddModule by remember { mutableStateOf(false) }
    var moduleName by remember { mutableStateOf("") }
    var moduleVersion by remember { mutableStateOf("1.0") }
    var moduleDescription by remember { mutableStateOf("") }

    fun moduleList(): List<ModuleItem> {
        val f = File(root, "modules.json")
        if (!f.exists()) return emptyList()
        return try {
            val a = JSONArray(f.readText())
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                ModuleItem(o.optString("name"), o.optString("version"), o.optString("description"), o.optString("fileName"))
            }
        } catch (_: Exception) { emptyList() }
    }
    var modules by remember { mutableStateOf(moduleList()) }
    fun saveModules(list: List<ModuleItem>) {
        val a = JSONArray()
        list.forEach { m ->
            a.put(JSONObject().put("name", m.name).put("version", m.version)
                .put("description", m.description).put("fileName", m.fileName))
        }
        File(root, "modules.json").writeText(a.toString())
        modules = list
    }

    val importZip = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                val name = queryDisplayName(context, uri).replace(Regex("[^A-Za-z0-9._-]"), "_")
                val safeName = if (name.endsWith(".zip", true)) name else "$name.zip"
                val target = uniqueFile(archives, safeName)
                context.contentResolver.openInputStream(uri)?.use { input -> target.outputStream().use { output -> input.copyTo(output) } }
                message = "ZIP imported: ${target.name}"
                refresh++
            } catch (e: Exception) { message = "Import failed: ${e.message}" }
        }
    }
    val exportZip = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri: Uri? ->
        val file = selectedZip
        if (uri != null && file != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
                message = "Export complete"
            } catch (e: Exception) { message = "Export failed: ${e.message}" }
        }
    }

    if (!unlocked) {
        MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Ink, surface = Panel, onSurface = White)) {
            Column(Modifier.fillMaxSize().background(Ink).padding(26.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Box(Modifier.size(76.dp).background(Red, RoundedCornerShape(22.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Shield, null, tint = Color.Black, modifier = Modifier.size(42.dp))
                }
                Spacer(Modifier.height(20.dp))
                Row(verticalAlignment = Alignment.CenterVertically) { Text("ONYX", color = Red, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp); Spacer(Modifier.width(7.dp)); Text("KERNEL", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp) }
                Text(if (isSettingPin) "CREATE YOUR SECURITY PIN" else "SECURE PERSONAL VAULT", color = Muted, fontSize = 11.sp, letterSpacing = 1.3.sp)
                Spacer(Modifier.height(24.dp))
                OutlinedTextField(value = pinInput, onValueChange = { if (it.length <= 6 && it.all(Char::isDigit)) pinInput = it }, label = { Text(if (isSettingPin) "Create 6-digit PIN" else "Enter 6-digit PIN") }, singleLine = true, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(), keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.NumberPassword))
                if (isSettingPin) {
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = confirmPin, onValueChange = { if (it.length <= 6 && it.all(Char::isDigit)) confirmPin = it }, label = { Text("Confirm PIN") }, singleLine = true, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(), keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.NumberPassword))
                }
                if (pinError.isNotBlank()) { Spacer(Modifier.height(8.dp)); Text(pinError, color = Red, fontSize = 12.sp) }
                Spacer(Modifier.height(16.dp))
                Button(onClick = {
                    if (isSettingPin) {
                        when { pinInput.length != 6 -> pinError = "PIN must contain exactly 6 digits"; confirmPin != pinInput -> pinError = "PINs do not match"; else -> savePin(pinInput) }
                    } else {
                        if (verifyPin(pinInput)) { unlocked = true; pinInput = ""; pinError = "" } else { pinError = "Incorrect PIN. Try again."; pinInput = "" }
                    }
                }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.Black)) { Text(if (isSettingPin) "SAVE PIN" else "UNLOCK APP", fontWeight = FontWeight.Bold) }
                if (!isSettingPin && fingerprintEnabled && biometricAvailable) {
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = { launchBiometric() }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Fingerprint, null); Spacer(Modifier.width(8.dp)); Text("UNLOCK WITH FINGERPRINT") }
                }
                if (isSettingPin) { Spacer(Modifier.height(12.dp)); Text("Your PIN is stored as a secure one-way hash on this phone.", color = Muted, fontSize = 10.sp) }
            }
        }
        return
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Red, background = Ink, surface = Panel, onBackground = White,
        onSurface = White, secondary = Red
    )) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Home", "ZIP Vault", "Modules", "Settings").forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = {
                                Icon(when(item) {
                                    "Home" -> Icons.Default.Home
                                    "ZIP Vault" -> Icons.Default.FolderZip
                                    "Modules" -> Icons.Default.Layers
                                    else -> Icons.Default.Settings
                                }, contentDescription = item)
                            },
                            label = { Text(item, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Red, selectedTextColor = Red,
                                indicatorColor = Red.copy(alpha = .13f),
                                unselectedIconColor = Muted, unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(Red, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Bolt, null, tint = Color.Black, modifier = Modifier.size(27.dp))
                    }
                    Spacer(Modifier.width(11.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) { Text("ONYX", color = Red, fontWeight = FontWeight.Black, fontSize = 20.sp, letterSpacing = 1.2.sp); Spacer(Modifier.width(5.dp)); Text("KERNEL", color = Gold, fontWeight = FontWeight.Black, fontSize = 20.sp, letterSpacing = 1.1.sp) }
                        Text("PERSONAL STORAGE SYSTEM", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    Text("V1.0", color = Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(20.dp))
                when (page) {
                    "Home" -> {
                        Text("YOUR SPACE. YOUR CONTROL.", color = Muted, fontSize = 11.sp, letterSpacing = 1.4.sp)
                        Spacer(Modifier.height(10.dp))
                        Row(Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(14.dp)).padding(horizontal = 15.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Person, null, tint = Gold); Spacer(Modifier.width(9.dp)); Column { Text("ROHITONYX_777", color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, letterSpacing = 1.sp); Text("PERSONAL FOLDER", color = Muted, fontSize = 9.sp, letterSpacing = 1.2.sp) } }
                        Spacer(Modifier.height(12.dp))
                        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(22.dp)).padding(20.dp)) {
                            Text("KERNEL VAULT", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("Keep your files\nunder your control.", color = White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 30.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("Offline storage • No account • No cloud", color = Muted, fontSize = 11.sp)
                            Spacer(Modifier.height(18.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                                StatBox("ZIP FILES", archives.listFiles()?.size ?: 0, Modifier.weight(1f))
                                StatBox("MODULES", modules.size, Modifier.weight(1f))
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                        Text("QUICK ACTIONS", color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Spacer(Modifier.height(10.dp))
                        ActionTile("Import ZIP archive", "Add a ZIP from your phone", Icons.Default.Add, onClick = { importZip.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) })
                        ActionTile("Open ZIP Vault", "Browse and export saved archives", Icons.Default.FolderZip, onClick = { page = "ZIP Vault" })
                        ActionTile("Manage Modules", "Keep module details organized", Icons.Default.Layers, onClick = { page = "Modules" })
                    }
                    "ZIP Vault" -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("ZIP VAULT", color = White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                                Text("Your saved archives", color = Muted, fontSize = 12.sp)
                            }
                            Button(onClick = { importZip.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) },
                                colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.Black)) {
                                Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("IMPORT")
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        val zips = remember(refresh) { archives.listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() } ?: emptyList() }
                        if (zips.isEmpty()) EmptyState("No ZIP files yet", "Tap IMPORT to add your first archive.")
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            items(zips, key = { it.name }) { file ->
                                Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(14.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.FolderZip, null, tint = Red, modifier = Modifier.size(28.dp))
                                        Spacer(Modifier.width(10.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(file.name, color = White, fontWeight = FontWeight.SemiBold)
                                            Text(formatSize(file.length()), color = Muted, fontSize = 11.sp)
                                        }
                                        IconButton(onClick = { selectedZip = file; exportZip.launch(file.name) }) {
                                            Icon(Icons.Default.FileDownload, "Export", tint = Red)
                                        }
                                        IconButton(onClick = {
                                            try { file.delete(); refresh++; message = "Archive deleted" }
                                            catch (_: Exception) { message = "Could not delete file" }
                                        }) { Icon(Icons.Default.Delete, "Delete", tint = Muted) }
                                    }
                                    TextButton(onClick = { selectedZip = file }) { Text("VIEW CONTENTS", color = Red, fontSize = 11.sp) }
                                    if (selectedZip == file) {
                                        val entries = remember(file, refresh) { readZipEntries(file) }
                                        Text("CONTENTS (${entries.size})", color = Red, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        entries.take(40).forEach { entry ->
                                            Text("• $entry", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(start = 5.dp, top = 3.dp))
                                        }
                                        if (entries.size > 40) Text("Showing first 40 entries", color = Muted, fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }
                    "Modules" -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("MODULE LIBRARY", color = White, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
                                Text("Organize module information only", color = Muted, fontSize = 11.sp)
                            }
                            Button(onClick = { showAddModule = true }, colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.Black)) {
                                Icon(Icons.Default.Add, null); Text(" ADD")
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        if (modules.isEmpty()) EmptyState("Your library is empty", "Add a module entry to organize its details.")
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            items(modules) { m ->
                                Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(15.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Layers, null, tint = Red)
                                        Spacer(Modifier.width(9.dp))
                                        Text(m.name, color = White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                        Text("v${m.version}", color = Red, fontSize = 11.sp)
                                    }
                                    if (m.description.isNotBlank()) Text(m.description, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 7.dp))
                                    if (m.fileName.isNotBlank()) Text("Archive: ${m.fileName}", color = Muted, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                    else -> {
                        Text("SETTINGS", color = White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                        Spacer(Modifier.height(12.dp))
                        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(16.dp)) {
                            Text("APP INFORMATION", color = Red, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Spacer(Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) { Text("ONYX", color = Red, fontWeight = FontWeight.Bold); Text(" KERNEL  •  Version 1.0.0", color = Gold, fontWeight = FontWeight.Bold) }
                            Text("Package: com.onyx.kernel", color = Muted, fontSize = 11.sp)
                            Text("All imported files are stored locally in app-private storage.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
                        }
                        Spacer(Modifier.height(12.dp))
                        Spacer(Modifier.height(12.dp))
                        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(16.dp)) {
                            Text("SECURITY", color = Red, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("App lock: 6-digit PIN", color = White, fontWeight = FontWeight.SemiBold)
                            Text("Fingerprint unlock", color = Muted, fontSize = 11.sp)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(if (biometricAvailable) "Enable fingerprint" else "Fingerprint not available on this phone", color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
                                Switch(checked = fingerprintEnabled, enabled = biometricAvailable, onCheckedChange = { enabled ->
                                    fingerprintEnabled = enabled
                                    securityPrefs.edit().putBoolean("fingerprint_enabled", enabled).apply()
                                })
                            }
                            TextButton(onClick = { pinInput = ""; confirmPin = ""; pinError = ""; isSettingPin = true; unlocked = false }) { Text("CHANGE PIN", color = Red) }
                        }
                        Text("No login • No cloud • No ads • No module auto-install", color = Muted, fontSize = 12.sp)
                    }
                }
                if (message.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(message, color = Red, fontSize = 11.sp)
                }
            }
        }
        if (showAddModule) {
            AlertDialog(
                onDismissRequest = { showAddModule = false },
                containerColor = Panel,
                title = { Text("Add module details", color = White) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(moduleName, { moduleName = it }, label = { Text("Module name") }, singleLine = true)
                        OutlinedTextField(moduleVersion, { moduleVersion = it }, label = { Text("Version") }, singleLine = true)
                        OutlinedTextField(moduleDescription, { moduleDescription = it }, label = { Text("Description") })
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (moduleName.isNotBlank()) {
                            saveModules(modules + ModuleItem(moduleName.trim(), moduleVersion.trim(), moduleDescription.trim(), ""))
                            moduleName = ""; moduleVersion = "1.0"; moduleDescription = ""
                            showAddModule = false
                        }
                    }) { Text("SAVE", color = Red) }
                },
                dismissButton = { TextButton(onClick = { showAddModule = false }) { Text("CANCEL", color = Muted) } }
            )
        }
    }
}

@Composable private fun StatBox(label: String, count: Int, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel2, RoundedCornerShape(13.dp)).padding(13.dp)) {
        Text(count.toString(), color = White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
        Text(label, color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
    }
}
@Composable private fun ActionTile(title: String, sub: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).background(Panel, RoundedCornerShape(14.dp)).clickable { onClick() }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Red, modifier = Modifier.size(25.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = White, fontWeight = FontWeight.SemiBold)
            Text(sub, color = Muted, fontSize = 11.sp)
        }
        Icon(Icons.Default.ChevronRight, null, tint = Muted)
    }
}
@Composable private fun EmptyState(title: String, detail: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 35.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.Inventory2, null, tint = Red, modifier = Modifier.size(40.dp))
        Spacer(Modifier.height(8.dp))
        Text(title, color = White, fontWeight = FontWeight.Bold)
        Text(detail, color = Muted, fontSize = 11.sp)
    }
}
private fun queryDisplayName(context: Context, uri: Uri): String {
    var name = "archive.zip"
    context.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val index = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
        if (index >= 0 && c.moveToFirst()) name = c.getString(index) ?: name
    }
    return name
}
private fun uniqueFile(dir: File, name: String): File {
    var candidate = File(dir, name); var i = 1
    while (candidate.exists()) {
        val base = name.substringBeforeLast(".")
        val ext = name.substringAfterLast(".", "")
        candidate = File(dir, "$base ($i).$ext"); i++
    }
    return candidate
}
private fun readZipEntries(file: File): List<String> = try {
    ZipFile(file).use { zip -> val e = zip.entries(); buildList { while (e.hasMoreElements()) add(e.nextElement().name) } }
} catch (_: Exception) { listOf("Unable to read archive (invalid or unsupported ZIP)") }
private fun formatSize(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "${bytes / 1024} KB"
    else -> String.format("%.2f MB", bytes / (1024.0 * 1024.0))
}

private fun hashPin(pin: String, salt: ByteArray): String {
    val spec = PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)
    return try {
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        Base64.encodeToString(bytes, Base64.NO_WRAP)
    } finally { spec.clearPassword() }
}
