# ONYX KERNEL — Android starter project

A native Kotlin + Jetpack Compose Android starter app with:
- Black interface with electric-blue ONYX and gold KERNEL branding
- Offline, app-private file storage
- ZIP import using Android's document picker
- ZIP archive listing / contents preview
- ZIP export using Android's save dialog
- Local module metadata library (name, version, description)
- No account, login, cloud service, ads, or automatic module execution

Personal folder label: `ROHITONYX_777`

## Build
1. Open this folder in Android Studio (Giraffe or newer; recommended current stable).
2. Let Gradle sync. JDK 17 is required.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated debug APK on your Android phone.

Application ID: `com.onyx.kernel`
Minimum Android: 8.0 (API 26)
Target SDK: 35

## Important
This is a source project, not a compiled APK. It must be built with the Android SDK/Gradle toolchain.
The current chat environment does not have an Android SDK configured to compile and sign an APK.
Imported ZIP files are copied into app-private storage and are removed if the app is uninstalled. Export important files before uninstalling.
The module library stores metadata only. It does not install, execute, or modify system modules.
No broad storage permission is requested; file selection/export uses Android's Storage Access Framework.
