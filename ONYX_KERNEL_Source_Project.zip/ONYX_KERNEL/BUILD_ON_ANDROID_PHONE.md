# Building from an Android phone

The supplied project is a standard Android Gradle project. The most reliable build path is Android Studio on a computer.
On a phone, use a trusted Android IDE/build environment that supports importing a complete Gradle Kotlin/Compose project, JDK 17, Gradle 8.9, and Android SDK 35. Not every mobile IDE supports Jetpack Compose or this Gradle setup.
Do not paste the Kotlin source into Sketchware Pro: Sketchware projects are a different format.
If your phone IDE cannot build Compose projects, use a compatible cloud Android build service or a computer with Android Studio.
